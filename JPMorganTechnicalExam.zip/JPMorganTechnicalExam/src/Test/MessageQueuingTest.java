package Test;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Test;

import Implementation.GateWayProducer;
import Implementation.JPMMessage;
import Implementation.ResourceConsumer;

public class MessageQueuingTest {

	private ResourceConsumer myResourceConsumer;
	private GateWayProducer myGateWayProducer;

	@Test
	public void  QueuingTest() throws InterruptedException {
		List<JPMMessage> myMessageSourcetestQueue = getMessagequeue();
		BlockingQueue<JPMMessage> testQueue = new ArrayBlockingQueue<JPMMessage>(100);
		int Number_of_Resources = getNumberOfRes();
		myGateWayProducer = new GateWayProducer(testQueue,
				myMessageSourcetestQueue);
		myGateWayProducer.start();
		for (int i = 0; i < Number_of_Resources; i++) {
			myResourceConsumer = new ResourceConsumer(testQueue, i);
			myResourceConsumer.start();
			
		}
		myResourceConsumer.join();
		myGateWayProducer.join();
		// This Assertion Confirms that all Messages on the Queue are processed
		// and the Queue is Empty.
		assertTrue(testQueue.isEmpty());

	}

	private int getNumberOfRes() {

		return 2;
	}

	/**
	 * This Method Creates Messages and Add them to the Queue. It generates 10
	 * messages, message ID will be 1 to n, Each message will get a Group ID -
	 * which will be between 1 to 5
	 * 
	 * @return
	 */
	protected static List<JPMMessage> getMessagequeue() {
		List<JPMMessage> myMessageSource = new ArrayList<JPMMessage>();
		int randomInt = 0;
		Random randomGenerator = new Random();

		for (int i = 0; i < 10; i++) {
			JPMMessage myMessage = new JPMMessage();
			randomInt = randomGenerator.nextInt(5);
			myMessage.setGroupID(randomInt);
			myMessage.setMessageID(i);

			myMessageSource.add(myMessage);
		}
		return myMessageSource;
	}

}
