package Test;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Test;

import Implementation.GateWayProducer;
import Implementation.JPMMessage;
import Implementation.ResourceConsumer;

public class MessageForwardingTest2 extends MessageForwardingTest {
	private ResourceConsumer myResourceConsumer;
	private GateWayProducer myGateWayProducer;

	// This Case performs Double Message, Double Resource Scenario.
	@Test
	public void DoubleMessageForwardingTest() throws InterruptedException {
		List<JPMMessage> SingleMessage = getMessage(2);
		BlockingQueue<JPMMessage> testQueue = new ArrayBlockingQueue<JPMMessage>(10);

		myGateWayProducer = new GateWayProducer(testQueue, SingleMessage);
		myGateWayProducer.start();
		for (int i = 0; i < 2; i++) {
			myResourceConsumer = new ResourceConsumer(testQueue, 0);
			myResourceConsumer.start();
			
		}
		myResourceConsumer.join();
		myGateWayProducer.join();
		// This Assertion Proves that two Messages have been sent to GateWay
		// when two
		// Resources are Available
		assertTrue(testQueue.isEmpty());
	}

}
