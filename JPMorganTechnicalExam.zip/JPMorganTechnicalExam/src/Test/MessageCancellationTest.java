package Test;

import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Test;

import Implementation.GateWayProducer;
import Implementation.JPMMessage;
import Implementation.ResourceConsumer;

public class MessageCancellationTest {
	private ResourceConsumer myResourceConsumer;
	private GateWayProducer myGateWayProducer;

	@Test
	public void SchedulerTest() throws InterruptedException {
		List<JPMMessage> myMessageSourcetestQueue = getMessagequeue();
		BlockingQueue<JPMMessage> testQueue = new ArrayBlockingQueue<JPMMessage>(100);
		int Number_of_Resources = getNumberOfRes();
		myGateWayProducer = new GateWayProducer(testQueue,
				myMessageSourcetestQueue);
		myGateWayProducer.start();
		for (int i = 0; i < Number_of_Resources; i++) {
			myResourceConsumer = new ResourceConsumer(testQueue, i);
			myResourceConsumer.start();
			
		}
		myResourceConsumer.join();
		myGateWayProducer.join();
		// Message Processing has been completed
		// The Following Two Assertions are confirming that Both Resource and
		// GateWay are not Active as there are No Messages on the Queue.
		assertFalse(myGateWayProducer.isAlive());
		assertFalse(myResourceConsumer.isAlive());
	}

	private int getNumberOfRes() {

		return 10;
	}

	/**
	 * This Method Creates Messages and Add them to the Queue. It generates 100
	 * messages, message ID will be 1 to n, Each message will get a Group ID -
	 * which will be between 1 to 9
	 * 
	 * @return
	 */
	protected static List<JPMMessage> getMessagequeue() {
		List<JPMMessage> myMessageSource = new ArrayList<JPMMessage>();
		int randomInt = 0;
		Random randomGenerator = new Random();
		for (int i = 0; i < 100; i++) {
			JPMMessage myMessage = new JPMMessage();
			randomInt = randomGenerator.nextInt(10);

			myMessage.setGroupID(randomInt);
			myMessage.setMessageID(i);
			myMessage.setCancellationFlag(true);

			myMessageSource.add(myMessage);
		}
		return myMessageSource;
	}

}
