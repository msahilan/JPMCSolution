package Test;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import org.junit.Test;

import Implementation.GateWayProducer;
import Implementation.JPMMessage;
import Implementation.ResourceConsumer;

public class MessageForwardingTest {
	private ResourceConsumer myResourceConsumer;
	private GateWayProducer myGateWayProducer;

	// This Case performs Single Message, Single Resource Scenario.
	@Test
	public void SingleMessageForwardingTest() throws InterruptedException {
		List<JPMMessage> SingleMessage = getMessage(1);
		BlockingQueue<JPMMessage> testQueue = new ArrayBlockingQueue<JPMMessage>(1);

		myGateWayProducer = new GateWayProducer(testQueue, SingleMessage);
		myGateWayProducer.start();

		myResourceConsumer = new ResourceConsumer(testQueue, 0);
		myResourceConsumer.start();
		myResourceConsumer.join();

		myGateWayProducer.join();
		// This Assertion Proves that Single Message has been sent to GateWay
		// when Single
		// Resource is Available
		assertTrue(testQueue.isEmpty());
	}

		protected List<JPMMessage> getMessage(int numOfMsg) {
		List<JPMMessage> myMessageSource = new ArrayList<JPMMessage>();
		for (int i = 1; i <= numOfMsg; i++) {
			JPMMessage myMessage = new JPMMessage();
			myMessage.setGroupID(i);
			myMessage.setMessageID(i);
			myMessageSource.add(myMessage);
		}
		return myMessageSource;
	}

}
