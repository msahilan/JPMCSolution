package Implementation;

import java.util.concurrent.BlockingQueue;

/**
 * This is the Consumer Class. Resources will act as Consumers and they will
 * take the messages from the Queue.
 * 
 * @author Ahilan
 *
 */
public class ResourceConsumer extends Thread {
	private final BlockingQueue<JPMMessage> queue;
	private final int consumerID;

	/**
	 * @param queue
	 * @param i
	 */
	public ResourceConsumer(BlockingQueue<JPMMessage> queue, int i) {
		this.queue = queue;
		this.consumerID = i + 1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		try {
			while (true) {
				 
				JPMMessage myJPMMessage = queue.take();
				System.out.println("Resource  " + consumerID + " is  processing  Message "+myJPMMessage.getMessageID() + " Group ID - " + myJPMMessage.getGroupID());
				myJPMMessage.completed();
			}
		} catch (InterruptedException ie) {
			// jus
		}
	}

}
