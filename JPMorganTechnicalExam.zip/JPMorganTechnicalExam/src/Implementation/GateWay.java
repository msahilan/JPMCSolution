package Implementation;

/**
 * @author Ahilan
 *
 */
public interface GateWay {
	public void send(Message msg);
}

