package Implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import javax.swing.JOptionPane;

/**
 * This is the Producer Class.Gate way will act as a Producer and It will put
 * the Messages on the Queue
 * 
 * @author Ahilan
 *
 */
public class GateWayProducer extends Thread implements GateWay {
	public final BlockingQueue<JPMMessage> queue;
	List<JPMMessage> messageSource;
	List<Integer> processedGroups = new ArrayList<Integer>();
	List<Integer> cancelledGroups = new ArrayList<Integer>();
	List<Integer> terminatedGroups = new ArrayList<Integer>();

	/**
	 * @param aqueue
	 * @param aMessageSource
	 */
	public GateWayProducer(BlockingQueue<JPMMessage> aqueue,
			List<JPMMessage> aMessageSource) {
		this.queue = aqueue;
		this.messageSource = aMessageSource;
	}

	@Override
	public void run() {

		// Start sending to the queue
		for (JPMMessage myJPMMessage : messageSource) {
			int groupID = myJPMMessage.getGroupID();
			processCancellation(myJPMMessage);
			processTermination(myJPMMessage);
			if (isProcessingRequired(groupID)) {
				List<JPMMessage> myGroupMessages = generateGroupMessage(groupID);
				for (JPMMessage myfilteredMsg : myGroupMessages) {
					send(myfilteredMsg);
				}
				if (!processedGroups.contains(groupID)) {
					processedGroups.add(groupID);
				}
			}
		}
	}

	/**
	 * @param myJPMMessage
	 */
	private void processTermination(JPMMessage myJPMMessage) {
		Integer mygroupID = myJPMMessage.getGroupID();
		if (myJPMMessage.getTerminationFlag()) {
			if (!terminatedGroups.contains(mygroupID)) {
				terminatedGroups.add(mygroupID);
			} else {
				JOptionPane
						.showMessageDialog(
								null,
								"Group Code "
										+ mygroupID
										+ " has been already Terminated, No Further Messages from this Group can be processed",
								"Terminated Group Message",
								JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	/**
	 * @param myJPMMessage
	 */
	private void processCancellation(JPMMessage myJPMMessage) {
		int mygroupID = myJPMMessage.getGroupID();
		if (myJPMMessage.getCancellationFlag()) {
			if (!cancelledGroups.contains(mygroupID)) {
				System.out.println("Group " + mygroupID
						+ " has been sent for Cancellation");
				cancelledGroups.add(mygroupID);
			}
		}
	}

	/**
	 * @param aGroupID
	 * @return
	 */
	private boolean isProcessingRequired(int aGroupID) {
		boolean isProcessingRequired = true;

		if (processedGroups.contains(aGroupID)
				|| cancelledGroups.contains(aGroupID)
				|| terminatedGroups.contains(aGroupID)) {
			isProcessingRequired = false;
		}
		return isProcessingRequired;
	}

	/**
	 * @param groupID
	 * @return
	 */
	private List<JPMMessage> generateGroupMessage(int groupID) {

		List<JPMMessage> myGroupList = new ArrayList<JPMMessage>();
		for (JPMMessage myJPMMessage : messageSource) {
			if (groupID == myJPMMessage.getGroupID()) {
				myGroupList.add(myJPMMessage);
			}
		}
		return myGroupList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see Implementation.GateWay#send(Implementation.Message)
	 */
	@Override
	public void send(Message msg) {
		JPMMessage myCurrentMsg = (JPMMessage) msg;
		System.out.println("\nMessage  " + myCurrentMsg.getMessageID()
				+ " is Queuing  up >>>" + " It belongs to Group -  "
				+ myCurrentMsg.getGroupID());

		try {
			queue.put(myCurrentMsg);

		} catch (InterruptedException e) {
			Thread.currentThread().interrupt(); // set interrupt flag
			System.out.println("Failed to put the Message on the Queue");
			e.printStackTrace();
		}
	}

}
