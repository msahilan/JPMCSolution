package Implementation;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

/**
 * This is the Starting point of the Application. This will create a Queue and
 * start both Producer and Consumer Threads.
 * 
 * @author Ahilan
 *
 */
public class ResourceScheduler {
	/**
	 * @param args
	 */
	public static void main(String args[]) {
		BlockingQueue<JPMMessage> queue = new ArrayBlockingQueue<JPMMessage>(256);
		List<JPMMessage> myMessageSource = getMessageSource();
		int resource_size = getResourceSize();
		GateWayProducer myGateWay = new GateWayProducer(queue, myMessageSource);
		myGateWay.start();
		for (int i = 0; i < resource_size; i++) {
			ResourceConsumer myResourceConsumer = new ResourceConsumer(queue, i);
			myResourceConsumer.start();
		}
	}

	private static int getResourceSize() {	

		return 5;
	}

	/**
	 * This Method Creates Messages and Add them to the Queue. It generates 100
	 * messages, message ID will be 1 to n, Each message will get a Group ID -
	 * which will be between 1 to 9
	 * 
	 * @return
	 */
	private static List<JPMMessage> getMessageSource() {
		List<JPMMessage> myMessageSource = new ArrayList<JPMMessage>();
		int randomInt = 0;
		Random randomGenerator = new Random();
		Random myrandomGenerator = new Random();
		for (int i = 0; i < 100; i++) {
			JPMMessage myMessage = new JPMMessage();
			randomInt = randomGenerator.nextInt(10);
			boolean value = randomGenerator.nextBoolean();
			boolean termiantionvalue = myrandomGenerator.nextBoolean();
			myMessage.setGroupID(randomInt);
			myMessage.setMessageID(i);
			myMessage.setCancellationFlag(value);
			myMessage.setTerminationFlag(termiantionvalue);

			myMessageSource.add(myMessage);
		}
		return myMessageSource;
	}
}
