package Implementation;

/**
 * @author Ahilan
 *
 */
public interface Message {
	public void completed();
	 
	 
}
