package Implementation;


/**
 * Message Object. provides Implementation for Message Interface.
 * @author Ahilan
 *
 */
public class JPMMessage  implements Message {
	private int groupID;
	private int MessageID;
	private boolean terminationFlag;
	private boolean cancellationFlag;
	

	/**
	 * @return
	 */
	public boolean getCancellationFlag() {
		return cancellationFlag;
	}

	/**
	 * @param cancellationFlag
	 */
	public void setCancellationFlag(boolean cancellationFlag) {
		this.cancellationFlag = cancellationFlag;
	}

	/**
	 * @return
	 */
	public boolean getTerminationFlag() {
		return terminationFlag;
	}

	/**
	 * @param terminationFlag
	 */
	public void setTerminationFlag(boolean terminationFlag) {
		this.terminationFlag = terminationFlag;
	}

	/**
	 * @return
	 */
	public int getMessageID() {
		return MessageID;
	}

	/**
	 * @param messageID
	 */
	public void setMessageID(int messageID) {
		MessageID = messageID;
	}

	/**
	 * @return
	 */
	public int getGroupID() {
		return groupID;
	}

	/**
	 * @param groupID
	 */
	public void setGroupID(int groupID) {
		this.groupID = groupID;
	}

	/* (non-Javadoc)
	 * @see Implementation.Message#completed()
	 */
	@Override
	public void completed() {
		System.out.println("Message ID " + MessageID + ", Group ID - "+ groupID+ " has been processed <<<<");

	}

}
